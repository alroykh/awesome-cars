// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatDialogModule } from '@angular/material/dialog';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { CarDialogComponent } from './car-dialog.component';
// import { MatToolbarModule } from '@angular/material/toolbar';
// import { MatSelectModule } from '@angular/material/select';
// import { MatButtonModule } from '@angular/material/button';
// import { MatInputModule } from '@angular/material/input';
// import { MatAutocompleteModule } from '@angular/material/autocomplete';

// @NgModule({
//   declarations: [CarDialogComponent],
//   imports: [
//     CommonModule,
//     FormsModule,
//     ReactiveFormsModule,
//     MatFormFieldModule,
//     MatToolbarModule,
//     MatSelectModule,
//     MatButtonModule,
//     MatDialogModule,
//     MatInputModule,
//     MatAutocompleteModule,
//   ],
//   exports: [CarDialogComponent],
// })
// export class CarDialogModule {}
