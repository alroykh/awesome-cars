import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealer-item',
  templateUrl: './dealer-item.component.html',
  styleUrls: ['./dealer-item.component.scss']
})
export class DealerItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
